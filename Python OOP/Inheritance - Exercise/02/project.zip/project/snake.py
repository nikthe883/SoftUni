from .reptile import Reptile

class Snake(Reptile):
    def __init__(self, name) -> None:
        super().__init__(name)