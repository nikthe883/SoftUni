from .mammal import Mammal

class Bear(Mammal):
    def __init__(self, name) -> None:
        super().__init__(name)