class Hero:

    username = ""
    level = 0

    def __str__(self) -> str:
        return f"{self.username} of type {self.__class__.__name__} has level {self.level}"