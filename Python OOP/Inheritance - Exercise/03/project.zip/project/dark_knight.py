from .knight import Knight

class DarkKnight(Knight):
    pass
