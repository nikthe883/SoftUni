from project.peaks.summit_peak import SummitPeak
from project.peaks.arctic_peak import ArcticPeak
from project.climbers.arctic_climber import ArcticClimber
from project.climbers.summit_climber import SummitClimber


class SummitQuestManagerApp:
    def __init__(self):
        self.climbers = []
        self.peaks = []

    def _find_climber(self, name):
        return next((climber for climber in self.climbers if climber.name == name), None)

    def _find_peak(self, name):
        return next((peak for peak in self.peaks if peak.name == name), None)

    def register_climber(self, climber_type: str, climber_name: str):
        if self._find_climber(climber_name):
            return f"{climber_name} has been already registered."
        
        if climber_type == "ArcticClimber":
            climber = ArcticClimber(climber_name)
        elif climber_type == "SummitClimber":
            climber = SummitClimber(climber_name)
        else:
            return f"{climber_type} doesn't exist in our register."

        self.climbers.append(climber)
        return f"{climber_name} is successfully registered as a {climber_type}."

    def peak_wish_list(self, peak_type: str, peak_name: str, peak_elevation: int):
        if self._find_peak(peak_name):
            return f"{peak_name} has already been added to the wish list."
        
        if peak_type == "ArcticPeak":
            peak = ArcticPeak(peak_name, peak_elevation)
        elif peak_type == "SummitPeak":
            peak = SummitPeak(peak_name, peak_elevation)
        else:
            return f"{peak_type} is an unknown type of peak."

        self.peaks.append(peak)
        return f"{peak_name} is successfully added to the wish list as a {peak_type}."

    def check_gear(self, climber_name: str, peak_name: str, gear: list):
        climber = self._find_climber(climber_name)
        peak = self._find_peak(peak_name)

        if not climber:
            return f"Climber {climber_name} is not registered yet."
        if not peak:
            return f"Peak {peak_name} is not part of the wish list."

        recommended_gear = set(peak.get_recommended_gear())
        climber_gear = set(gear)

        if climber_gear >= recommended_gear:
            climber.is_prepared = True
            return f"{climber_name} is prepared to climb {peak_name}."
        else:
            missing_gear = recommended_gear - climber_gear
            climber.is_prepared = False
            return f"{climber_name} is not prepared to climb {peak_name}. Missing gear: {', '.join(sorted(missing_gear))}."

    def perform_climbing(self, climber_name: str, peak_name: str):
        climber = self._find_climber(climber_name)
        peak = self._find_peak(peak_name)

        if not climber:
            return f"Climber {climber_name} is not registered yet."
        if not peak:
            return f"Peak {peak_name} is not part of the wish list."
        if not climber.is_prepared or not climber.can_climb():
            return f"{climber_name} cannot climb {peak_name} at this time."

        climber.climb(peak)
        return f"{climber_name} conquered {peak_name} whose difficulty level is {peak.calculate_difficulty_level()}."

    def get_statistics(self):
        stats = "Total climbed peaks: {}\n**Climber's statistics:**\n".format(
            sum(len(climber.conquered_peaks) for climber in self.climbers))
        for climber in sorted(self.climbers, key=lambda x: (-len(x.conquered_peaks), x.name)):
            stats += "{}: /// Climber name: {} * Left strength: {:.1f} * Conquered peaks: {} ///\n".format(
                type(climber).__name__, climber.name, climber.strength, ", ".join(climber.conquered_peaks))
        return stats.strip()
